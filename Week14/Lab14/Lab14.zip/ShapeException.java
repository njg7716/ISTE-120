public class ShapeException extends Exception{
    public ShapeException(String message){super(message);}
}