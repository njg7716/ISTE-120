
public class TestPicture{
   public static void main (String[] args){
      Picture p = new Picture();
      p.draw();
   }
}