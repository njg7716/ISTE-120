
public class TestPicture1{
   public static void main (String[] args){
      Picture1 p = new Picture1();
      p.draw();
   }
}