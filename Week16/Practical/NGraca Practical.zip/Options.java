public interface Options{
    public final static String SURGICAL_WING = "D";
    public final static String MATERNITY_WING = "B";
    public final static int TV = 1;
    public final static int NO_TV = 2;
    public final static int UNKNOWN = -1;
}